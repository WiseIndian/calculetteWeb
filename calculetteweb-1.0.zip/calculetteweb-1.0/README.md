The source code of [occurrenc.es](https://occurrenc.es)

![Colorify example use](colorifyExample.png)
